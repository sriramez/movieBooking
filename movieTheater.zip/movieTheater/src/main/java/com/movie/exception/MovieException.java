package com.movie.exception;

public class MovieException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	MovieException(String s) {
		super(s);
	}
}
