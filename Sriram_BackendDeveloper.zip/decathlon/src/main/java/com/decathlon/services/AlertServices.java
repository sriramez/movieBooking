package com.decathlon.services;

import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.decathlon.Repository.TeamRepository;
import com.decathlon.model.Developer;
import com.decathlon.model.Response;
import com.decathlon.model.Team;

@Service
public class AlertServices {
	
	@Autowired
	TeamRepository repo;
	
	
	@Autowired
	RestTemplate template;
	
	public Response createTeam(Team team)
	{
		if(team!=null)
		{
			String teamName = team.getTeamName();
			if(teamName==null || teamName.isEmpty())
			{
				return new Response(0, "invalid team name");
			}
			else if(team.getDevelopers()==null)
			{
				return new Response(0, "team should contain atleast one developer");
			}
			else if(team.getDevelopers().size()==0)
			{
				return new Response(0, "team should contain atleast one developer");
			}
			Team teamFromDb = repo.save(team);
			return new Response(1,"Team created succesfully:teamId="+teamFromDb.getId());
		}
		return new Response(0, "Entered team is invalid");
	}
	
	
	public Response alertTeam(int id) {
		
		if(id==0)
		{
			return new Response(0, "Entered teamid is invalid");
		}
		Optional<Team> team = repo.findById(Long.valueOf(id));
		if(!team.isPresent())
		{
			return new Response(0, "Entered team doesnot exist");
		}
		else
		{
			List<Developer> developers = team.get().getDevelopers();
			
			int randomNum = ThreadLocalRandom.current().nextInt(0, developers.size());
			Developer dev = developers.get(randomNum);
			
			ResponseEntity<String> response
			  = template.getForEntity("https://run.mocky.io/v3/fd99c100-f88a-4d70-aaf7-393dbbd5d99f?phone_number="+dev.getPhoneNumber(), String.class);
			
			JSONObject jsonResponse  = new JSONObject(response.getBody());  
			if(jsonResponse.has("success"))
			{
				return new Response(1, dev.getName()+" is successfully notified");
			}
			else
			{
				return new Response(0, dev.getName()+"is not notified");
			}
			
		}
	}
	
	
}
