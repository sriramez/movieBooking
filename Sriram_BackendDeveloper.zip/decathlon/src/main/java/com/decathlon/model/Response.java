package com.decathlon.model;

public class Response {

	int status;
	
	String message;
	
	public Response(int status,String message)
	{
		this.status = status;
		this.message = message;
	}
	
	@Override
	public String toString() {
	
		return "{status:\""+status+"\",message:\""+message+"\"}";
	}
	
	
}
