package com.decathlon.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.decathlon.model.Response;
import com.decathlon.model.Team;
import com.decathlon.services.AlertServices;

@RestController
public class AppController {
	
	@Autowired
	AlertServices service;
	
	@PostMapping("team")
	public String createTeam(@RequestBody Team team)
	{
		return service.createTeam(team).toString();
	}
	
	@PostMapping("{team_id}/alert")
	public String alertTeam(@PathVariable int team_id)
	{
		return service.alertTeam(team_id).toString();
	}

}
