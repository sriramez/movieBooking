package com.decathlon.Repository;


import org.springframework.data.repository.CrudRepository;

import com.decathlon.model.Team;

@org.springframework.stereotype.Repository
public interface TeamRepository extends CrudRepository<Team, Long>
{

}
