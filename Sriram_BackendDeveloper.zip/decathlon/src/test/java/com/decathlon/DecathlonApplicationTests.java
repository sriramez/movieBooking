package com.decathlon;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestTemplate;

import com.decathlon.Repository.TeamRepository;
import com.decathlon.model.Developer;
import com.decathlon.model.Response;
import com.decathlon.model.Team;
import com.decathlon.services.AlertServices;

@SpringBootTest
class DecathlonApplicationTests {

	@Autowired
	AlertServices service;
	
	@MockBean
	TeamRepository repo;
	
	@MockBean
	RestTemplate template;
	
	@Test
	void contextLoads() {
	}
	
	@Test
	public void createAlertServiceTest()
	{
		Team team = new Team();
		team.setId(Long.valueOf(1));
		team.setTeamName("test");
		Developer dev = new Developer();
		List<Developer> devlopers = new ArrayList<Developer>();
		devlopers.add(dev);
		team.setDevelopers(devlopers);
		when(repo.save(team)).thenReturn(team);
		Response response =service.createTeam(team);
		assertEquals(response.toString(), "{status:\"1\",message:\"Team created succesfully:teamId=1\"}");
	}
	
	@Test
	public void createAlertServiceWillDevelopersAsNullTest()
	{
		Team team = new Team();
		team.setId(Long.valueOf(1));
		team.setTeamName("test");
		team.setDevelopers(null);
		when(repo.save(team)).thenReturn(team);
		Response response =service.createTeam(team);
		assertEquals(response.toString(), "{status:\"0\",message:\"team should contain atleast one developer\"}");
	}
	
	@Test
	public void createAlertServiceWillDevelopersWithEmptyListTest()
	{
		Team team = new Team();
		team.setId(Long.valueOf(1));
		team.setTeamName("test");
		List<Developer> devlopers = new ArrayList<Developer>();
		team.setDevelopers(devlopers);
		when(repo.save(team)).thenReturn(team);
		Response response =service.createTeam(team);
		assertEquals(response.toString(), "{status:\"0\",message:\"team should contain atleast one developer\"}");
	}
	
	@Test
	public void createAlertServiceWillDevelopersWithInvalidTeamNameTest()
	{
		Team team = new Team();
		team.setId(Long.valueOf(1));
		team.setTeamName("");
		List<Developer> devlopers = new ArrayList<Developer>();
		team.setDevelopers(devlopers);
		when(repo.save(team)).thenReturn(team);
		Response response =service.createTeam(team);
		assertEquals(response.toString(), "{status:\"0\",message:\"invalid team name\"}");
	}
	
	@Test
	public void sendAlertTest()
	{
		Team team = new Team();
		team.setId(Long.valueOf(1));
		team.setTeamName("test");
		Developer dev = new Developer();
		List<Developer> devlopers = new ArrayList<Developer>();
		devlopers.add(dev);
		team.setDevelopers(devlopers);
		Optional<Team> returnedTeam = Optional.of(team);
		
		when(repo.findById(Long.valueOf(1))).thenReturn(returnedTeam);
		ResponseEntity<String> value = new ResponseEntity<String>("{\"success\":\"alert sent\"}", HttpStatus.CREATED);
		when(template.getForEntity("https://run.mocky.io/v3/fd99c100-f88a-4d70-aaf7-393dbbd5d99f?phone_number="+dev.getPhoneNumber(), String.class)).thenReturn(value );
		Response response = service.alertTeam(1);
		assertEquals(response.toString(), "{status:\"1\",message:\"null is successfully notified\"}");
	}
	
	
	@Test
	public void sendAlertWhenTeamNotPresentTest()
	{
		Optional<Team> returnedTeam = Optional.empty();
		
		when(repo.findById(Long.valueOf(1))).thenReturn(returnedTeam);
		ResponseEntity<String> value = new ResponseEntity<String>("{\"success\":\"alert sent\"}", HttpStatus.CREATED);
		when(template.getForEntity("https://run.mocky.io/v3/fd99c100-f88a-4d70-aaf7-393dbbd5d99f?phone_number="+1, String.class)).thenReturn(value );
		Response response = service.alertTeam(1);
		assertEquals(response.toString(), "{status:\"0\",message:\"Entered team doesnot exist\"}");
	}

}
